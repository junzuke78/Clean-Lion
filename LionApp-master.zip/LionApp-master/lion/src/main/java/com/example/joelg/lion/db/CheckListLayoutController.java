package com.example.joelg.lion.db;

import android.support.v7.widget.RecyclerView;

/**
 * Created by joelg on 4/12/2017.
 */

public class CheckListLayoutController {

    private RecyclerView recyclerView;


}
