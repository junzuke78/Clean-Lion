package com.example.joelg.lion;

import java.util.ArrayList;

/**
 * Created by joelg on 18/12/2017.
 */

public class footer_toolbar extends ArrayList {


}
