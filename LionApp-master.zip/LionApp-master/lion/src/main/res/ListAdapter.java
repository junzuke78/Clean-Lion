import android.widget.ArrayAdapter;

import java.util.ArrayList;

/**
 * Created by joelg on 24/11/2017.
 */

public class ListAdapter extends ArrayAdapter {


}
